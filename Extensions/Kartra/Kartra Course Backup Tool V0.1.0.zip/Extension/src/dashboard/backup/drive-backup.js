/**
 * drive-backup.js — Google Drive backup writer
 *
 * Implements the writer interface expected by KartraOrchestrator:
 *   { write(path, url): Promise<{ ok, error? }> }
 *
 * Each write sends a "drive-upload-file" message to background/drive.js,
 * which resolves the folder hierarchy in Drive (creating any missing folders),
 * then streams the source URL response body directly into a resumable Drive
 * upload — no JS-side buffering of file bytes.
 */

class DriveBackup {
   constructor({ memberships, selected, rootFolder,
      onProgress, onDone, onError, onFileStatus, getFileStatus,
      resumeAtPostId, retryPostId }) {
      this.memberships = memberships;
      this.selected = selected;
      this.rootFolder = rootFolder;
      this.onProgress = onProgress || (() => { });
      this.onDone = onDone || (() => { });
      this.onError = onError || (() => { });
      this.onFileStatus = onFileStatus || (() => { });
      this.getFileStatus = getFileStatus || (() => undefined);
      this.resumeAtPostId = resumeAtPostId || null;
      this.retryPostId = retryPostId || null;
      this._run();
   }

   // ─── WRITER ──────────────────────────────────────────────────────────────────

   /**
    * The writer object passed to KartraOrchestrator.
    * Sends each file to background/drive.js via "drive-upload-file".
    * Retries up to 3 times on transient errors (rate limits, server errors).
    */
   _writer = {
      write: async (path, url) => {
         const MAX_TRIES = 3;

         for (let attempt = 0; attempt < MAX_TRIES; attempt++) {
            try {
               const result = await chrome.runtime.sendMessage({
                  type: "drive-upload-file",
                  path,
                  url,
               });

               if (result?.ok) return { ok: true };

               const err = result?.error || "Unknown Drive error";
               const retryable = /429|500|503|rate.?limit|timeout|network/i.test(err);
               if (!retryable || attempt === MAX_TRIES - 1) {
                  return { ok: false, error: err };
               }

            } catch (error) {
               // sendMessage throws if the service worker is inactive
               if (attempt === MAX_TRIES - 1) {
                  return { ok: false, error: error.message };
               }
            }

            // Exponential back-off before retrying
            await new Promise((r) => setTimeout(r, 1_000 * 2 ** attempt));
         }

         return { ok: false, error: "Failed after 3 attempts" };
      },
   };

   // ─── RUN ─────────────────────────────────────────────────────────────────────

   _run = async () => {
      try {
         // First, verify Drive is connected before starting
         const state = await chrome.runtime.sendMessage({ type: "get-drive-state" });
         if (!state?.connected) {
            return this.onError(
               new Error("Google Drive is not connected. Click the Drive option and sign in, then try again."),
            );
         }

         // Then, run the backup using the orchestrator with the Drive writer
         this._orchestrator = new KartraOrchestrator({
            memberships: this.memberships,
            selected: this.selected,
            rootFolder: this.rootFolder,
            writer: this._writer,
            onFileStatus: this.onFileStatus,
            getFileStatus: this.getFileStatus,
            onProgress: this.onProgress,
            onDone: this.onDone,
            onError: this.onError,
            resumeAtPostId: this.resumeAtPostId,
            retryPostId: this.retryPostId,
         });

      } catch (error) {
         console.error("[Kartra Backup] Drive backup error", error);
         this.onError(error);
      }
   };

   cancel = () => this._orchestrator?.cancel();
}
